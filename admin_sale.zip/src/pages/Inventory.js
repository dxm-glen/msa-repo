import React, { useState } from 'react';
import InventoryList from '../components/InventoryList';

function Inventory() {
  const [inventory] = useState([
    { id: 1, name: 'Item A', quantity: 10, price: 100 },
    { id: 2, name: 'Item B', quantity: 20, price: 200 },
    { id: 3, name: 'Item C', quantity: 30, price: 300 },
  ]);

  return (
    <div>
      <h1>재고 목록</h1>
      <InventoryList items={inventory} />
    </div>
  );
}

export default Inventory;
