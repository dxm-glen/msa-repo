import React from 'react';

function InventoryItem({ item }) {
  return (
    <div className="inventory-item">
      <h2>{item.name}</h2>
      <p>수량: {item.quantity}</p>
      <p>가격: ${item.price}</p>
    </div>
  );
}

export default InventoryItem;
